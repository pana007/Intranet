<?php
// Template Name: Registro Intranet
?>
<?php 
if($_SERVER['REQUEST_METHOD'] == 'POST'):

$username = $_POST['user_login'];
$password = $_POST['user_password'];
$email = $_POST['email'];

$new_user = wp_create_user($username, $password, $email);
if(is_wp_error($new_user)):
  header('Location:'.home_url());
else:
  header('Location:'.home_url('log-in/'));
endif;
endif; 

?>

<?php
wp_head();
get_header('register');
?>

<h1>Registro</h1>  
<?php 

$args = array(
  'menu'                 => 'nav',
  'container'            => 'div',
  'container_class'      => 'container_menu_front_page_class',
  'container_id'         => 'container_menu_front_page_id',
  'menu_class'           => 'menu_front_page',
  'menu_id'              => 'menu_front_page',
);

wp_nav_menu($args); ?>

<form action="" method='post'>
  <input type="text" placeholder='Nombre de usuario' required name='user_login' class="inpt inpt1">
  <input type="email" placeholder='Email' required name='email' class="inpt inpt2">
  <input type="password" placeholder='Contraseña' required name='user_password' class="inpt inpt3">
  <button>Registrarme</button>
</form>

<?php
wp_footer();
get_footer('register');
?>
</body>
</html>