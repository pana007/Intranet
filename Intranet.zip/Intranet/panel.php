<?php
// Template Name: Panel Intranet
?>

<?php
$current_user = wp_get_current_user();
if(!is_user_logged_in($current_user)){
  header('Location:'.home_url('log-in/'));
}
?>

<?php
wp_head();
get_header('panel');
?>

<h1>Panel Intranet</h1>

<?php

$redirect_logout = get_home_url();
$url_logout = wp_logout_url( $redirect_logout );


$argsPanel = array(
  'menu'                 => 'Menu Panel',
  'container'            => 'div',
  'container_class'      => 'container_menu_panel_class',
  'container_id'         => 'container_menu_panel_id',
  'menu_class'           => 'menu_panel_page',
  'menu_id'              => 'menu_panel_page',
);

wp_nav_menu($argsPanel); ?>


<div class="salu2">
  <h2>Hola <?php _e($current_user->user_login); ?>!</h2>
  <p>Esperamos que te encuentres complacido con nuestro sitio web. 
     A continuación tendras acceso a páginas, documentos, clientes, 
     facturas y mucho más, que solo los usuarios de nuestra <b>Intranet</b> 
     pueden tener. <br><br>
    Tú número de identificación es el <span><b><?php _e($current_user->ID); ?></b></span>, se tendra
    en cuenta en futuras ocasiones, no lo tienes que guardar, nosotros nos encargaremos
    de recordartelo.
    </p>
  <a href="#section_update" class="mas">Aprender más</a>
</div>
<br>
<br>
<br>
<br>
<br>

<hr>

<div class="section_update" id="section_update">
  <?php
  $current_user_perfil = wp_get_current_user();
  _e('<h3 class="user_name">'. $current_user_perfil->user_login . '</h3>');
  _e(get_avatar($current_user_perfil->ID));
  _e('<p class="pinfo"><span class"sps">Email</span>: '. $current_user_perfil->user_email. '</p>');
  _e('<p class="pinfo"><span class"sps">Nombres</span>: '. $current_user_perfil->user_firstname. '</p>');
  _e('<p class="pinfo"><span class"sps">Apellidos</span>: '. $current_user_perfil->user_lastname. '</p>');
  _e('<p class="pinfo"><span class"sps">Id</span>: '. $current_user_perfil->ID. '</p>');

  ?> 
  <a href="<?= home_url('update-data/'); ?>" class="act">Actualizar datos</a>
</div>

<?php 
wp_footer();
get_footer('panel');
?>