<?php 
wp_head(); 
get_header();
?>


<h1>Intranet</h1>

<?php
$current_user = wp_get_current_user(); 
if(!is_user_logged_in($current_user)){ 

$args = array(
  'menu'                 => 'nav',
  'container'            => 'div',
  'container_class'      => 'container_menu_front_page_class',
  'container_id'         => 'container_menu_front_page_id',
  'menu_class'           => 'menu_front_page',
  'menu_id'              => 'menu_front_page',
);

wp_nav_menu($args); 

}else {
  $argsPanel = array(
    'menu'                 => 'Menu Panel',
    'container'            => 'div',
    'container_class'      => 'container_menu_panel_class',
    'container_id'         => 'container_menu_panel_id',
    'menu_class'           => 'menu_panel_page',
    'menu_id'              => 'menu_panel_page',
  );
  
  wp_nav_menu($argsPanel);
}
?>
<div class="content">
  <h2>Lorem, ipsum.</h2>
  <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Autem itaque veniam ipsum aliquam veritatis voluptate unde neque accusamus repudiandae dolore enim iusto distinctio dignissimos consequuntur voluptatum magnam, soluta perferendis sed aspernatur. Rem adipisci labore accusantium. Autem, aliquam culpa hic dolorum quo distinctio fugiat perferendis, eveniet soluta commodi quas? Cupiditate, neque!</p>
  <img src="<?= get_template_directory_uri(); ?>/pics/img1.svg" alt="img1" class="img1">
</div>



<?php
wp_footer(); 
get_footer();
?>