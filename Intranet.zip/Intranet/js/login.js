let as = document.querySelectorAll('a');

let z = 0;

while(z < 3) {
  as[z].classList.add('prmlnk');
  z++;
}

let prmlnks = document.querySelectorAll('.prmlnk');
console.log(prmlnks);

const inpts = document.querySelectorAll('.inpt');

inpts.forEach((n)=>{
  n.addEventListener('click', (e)=>{
    let currentInpt = e.currentTarget;
    currentInpt.style.borderBottom = '.15rem solid #6c64fb';
    currentInpt.style.color = 'rgba(255, 255, 255, 0.75)';
  });
});