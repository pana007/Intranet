let as = document.querySelectorAll('a');

let z = 0;

while(z < 3) {
  as[z].classList.add('prmlnk');
  z++;
}

let prmlnks = document.querySelectorAll('.prmlnk');
console.log(prmlnks);

let ass = !!document.getElementById('menu_panel_page');
if(ass) {

  const ul = document.querySelector('.menu_panel_page');
  console.log(ul);
  const li = document.createElement('li');
  li.classList.add('logout_li');
  ul.appendChild(li);
  const a = document.createElement('a');
  a.href='http://localhost:8888/pw1/wordpress/wp-login.php?action=logout&redirect_to=http%3A%2F%2Flocalhost%3A8888%2Fpw1%2Fwordpress&_wpnonce=69786c5966';
  a.textContent = 'Log out';
  a.classList.add('logout');
  a.classList.add('prmlnk');
  as[3].classList.add('prmlnk');
  li.appendChild(a);
}