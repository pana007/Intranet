<?php
// Template Name: Log in Intranet
?>

<?php
if($_SERVER['REQUEST_METHOD'] == 'POST') {
  $creds = array();
  $creds['user_login'] = $_POST['user_login'];
  $creds['user_password'] = $_POST['user_password'];
  $creds['remember'] = false;

  $validation = wp_signon($creds);
  if(is_wp_error($validation)){
    echo 'algo salio mal';
  }else {
    header('Location:'.home_url('panel/'));
  }
}
?>


<?php
wp_head();
get_header('login');
?>



<h1>Log in</h1>

<?php $args = array(
  'menu'                 => 'nav',
  'container'            => 'div',
  'container_class'      => 'container_menu_front_page_class',
  'container_id'         => 'container_menu_front_page_id',
  'menu_class'           => 'menu_front_page',
  'menu_id'              => 'menu_front_page',
);

wp_nav_menu($args); ?>

<form action="" method='post'>
  <input type="text" placeholder='Nombre de usuario' required name='user_login' class="inpt inpt1">
  <input type="password" placeholder='Contraseña' required name='user_password' class="inpt inpt3">
  <a href="<?= home_url('wp-login.php?action=lostpassword');?>" class="lost">Olvide mi Contraseña</a>
  <button>Entrar</button>
</form>

<?php
wp_footer();
get_footer('login');
?>
