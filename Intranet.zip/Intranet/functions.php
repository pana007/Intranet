<?php

// ___ Scripts y Styles ___

function Intranet_styles_scripts() {

  $id = get_the_ID();
  switch($id) {

    case 244:
      wp_enqueue_style('style_registro', get_template_directory_uri() . '/stylesheets/register.css');
      wp_enqueue_script('script_registro', get_template_directory_uri() . '/js/register.js', array(), '', true); 
    break;

    case 246:
      wp_enqueue_style('style_login', get_template_directory_uri() . '/stylesheets/login.css');
      wp_enqueue_script('script_login', get_template_directory_uri() . '/js/login.js', array(), '', true); 
    break;

    case 252:
      wp_enqueue_style('style_panel', get_template_directory_uri() . '/stylesheets/panel.css');
      wp_enqueue_script('script_panel', get_template_directory_uri() . '/js/panel.js', array(), '', true); 
    break;

    case 264:
      wp_enqueue_style('style_lost_password', get_template_directory_uri() . '/stylesheets/lost.css');
      wp_enqueue_script('script_lost_password', get_template_directory_uri() . '/js/lost.js', array(), '', true); 
    break;

    case 266:
      wp_enqueue_style('style_update', get_template_directory_uri() . '/stylesheets/update.css');
      wp_enqueue_script('script_update', get_template_directory_uri() . '/js/update.js', array(), '', true); 
    break;

    default: 
    wp_enqueue_style('style1', get_template_directory_uri() . '/style.css');
    wp_enqueue_script('script1', get_template_directory_uri() . '/js/script1.js', array(), '', true);    

    }

}

add_action('wp_enqueue_scripts', 'Intranet_styles_scripts', 1);


// ___ Menús ___

add_action('after_setup_theme', 'Intranet_menu_front');

function Intranet_menu_front() {
  register_nav_menu('Menú Front Page', 'Menú principal');
}

// Menú Panel Solo usuarios

add_action('after_setup_theme', 'Intranet_menu_front');

function Intranet_menu_front_users() {
  register_nav_menu('Menu Panel', 'Menú Interno');
}