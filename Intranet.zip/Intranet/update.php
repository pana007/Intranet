<?php
//Template Name: Update Intranet
?>

<?php
if($_SERVER['REQUEST_METHOD'] == 'POST'){
  $id= get_current_user_id();
  $email = $_POST['email'];
  $firstnames = $_POST['firstnames'];
  $lastnames = $_POST['lastnames'];

  $dts = array(
    'ID' => $id,
    'user_email' => $email,
    'first_name' => $firstnames,
    'last_name' => $lastnames,
  );

  wp_update_user($dts);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
<?php
wp_head(); 
?>
</head>
<body>
  
<h1>Actualizar Datos</h1>

<?php

$redirect_logout = get_home_url();
$url_logout = wp_logout_url( $redirect_logout );


$argsPanel = array(
  'menu'                 => 'Menu Panel',
  'container'            => 'div',
  'container_class'      => 'container_menu_panel_class',
  'container_id'         => 'container_menu_panel_id',
  'menu_class'           => 'menu_panel_page',
  'menu_id'              => 'menu_panel_page',
);

wp_nav_menu($argsPanel); ?>

<form action="" method='post'>
  <input type="text" class="inpt" name='email' placeholder='Email' value='<?= wp_get_current_user()->user_email?>'>
  <input type="text" class="inpt" name='firstnames' placeholder='Nombres' value='<?= wp_get_current_user()->user_firstname?>'>
  <input type="text" class="inpt" name='lastnames' placeholder='Apellidos' value='<?= wp_get_current_user()->user_lastname?>'>
  <button>Actualizar</button>
</form>

<?php
wp_footer(); 
?>
</body>
</html>